<?php
require dirname(__FILE__) . '/../../../ext/pdo/tests/pdo_test.inc';
$db = PDOTest::test_factory(dirname(__FILE__) . '/common.phpt');

var_dump($db->getAttribute(PDO::FOURD_ATTR_PREFERRED_IMAGE_TYPES) == 'png');

$types = array('gif','png','jpg','tiff','psd','pdf','unknown');

foreach($types as $type) {
  print "$type\n";
  var_dump($db->setAttribute(PDO::FOURD_ATTR_PREFERRED_IMAGE_TYPES, $type));
  var_dump($db->getAttribute(PDO::FOURD_ATTR_PREFERRED_IMAGE_TYPES) == $type);

}

?>
