<?php
if (getenv('REDIR_TEST_DIR') === false) putenv('REDIR_TEST_DIR='.dirname(__FILE__) . '/../../pdo/tests/');
require_once getenv('REDIR_TEST_DIR') . 'pdo_test.inc';
$dbh = PDOTest::factory();

echo "silence\n";

$dbh->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_SILENT );
$dbh->exec('erreur flagrante SQL');

echo "---\n";
$dbh->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING );

@$dbh->exec('erreur flagrante SQL');
$erreur = $dbh->errorInfo();
print_r($erreur);

echo "---\n";
echo "exceptions\n";

$dbh->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );

		try {
$dbh->exec('erreur flagrante SQL');
		} catch (PDOException $e) {
			print("message : " . $e->getMessage()."\n");
			print("code : " . $e->getCode()."\n");
		}
?>
