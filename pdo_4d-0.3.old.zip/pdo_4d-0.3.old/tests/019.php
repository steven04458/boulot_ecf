<?php
$db = PDOTest::test_factory(dirname(__FILE__) . '/common.phpt');

$tests_types = array( array('gif','png'),
                      array('gif','jpg'),
                      array('jpg','png'),
                      array('jpg'),
                      array('png'),
                      array('gif'),
                      array('gif','png','jpg'),
);
//


foreach($tests_types as $types) {
    $db->setAttribute(PDO::FOURD_ATTR_PREFERRED_IMAGE_TYPES,join(' ', $types));

    $r = @$db->query('SELECT image, type FROM testImage');
    $l = $r->fetchall();

    $retour = array();
    foreach($l as $ligne) {
        if (in_array($ligne['type'], $types)) {
            $retour[] = $ligne['type'];
        }
    }

    var_dump(count(array_diff($retour, $types)) or count(array_diff($types, $retour)));
}

?>
