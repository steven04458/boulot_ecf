<?php
require dirname(__FILE__) . '/../../../ext/pdo/tests/pdo_test.inc';
$db = PDOTest::test_factory(dirname(__FILE__) . '/common.phpt');
$db->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );

$db->query('CREATE TABLE test ( c TEXT )');
$db->query("insert into test values ( 'sa;df' )");

$requetes = array('SELECT image, type FROM testImage;SELECT image, type FROM testImage',
                  "select *,[id';d],'to'';to','coucou[]' from toto;insert tata",
                  "select *,[id';d],'to'';to','coucou[]' from toto;\ninsert tata",
                  "select *,[id'une chaine'[]]tto;d],'to'';to','coucou[]' from toto; insert tata"
                    );


foreach($requetes as $id => $requete) {
		try {
            @$db->exec($requete);
		} catch (PDOException $e) {
//			print("message : " . $e->getMessage()."\n");
			print("$id) code : " . $e->getCode()."\n");
		}
}

// ces requetes doivent passer
$requetes = array('SELECT c as [oui;oui] FROM test',
                  'SELECT c as [oui;oui] FROM test;',
                  'SELECT c as [oui;oui] FROM test as [non;non]',
                  "SELECT c as [oui;oui] FROM test as [non;non] where c = ';'",
                    );


foreach($requetes as $id => $requete) {
		try {
            $r = $db->query($requete);
            var_dump(is_object($r));
		} catch (PDOException $e) {
//			print("message : " . $e->getMessage()."\n");
			print("$id) code : " . $e->getCode()."\n");
		}
}




$db->query('DROP TABLE test');

?>
