<?php
if (getenv('REDIR_TEST_DIR') === false) putenv('REDIR_TEST_DIR='.dirname(__FILE__) . '/../../pdo/tests/');
require_once getenv('REDIR_TEST_DIR') . 'pdo_test.inc';
$db = PDOTest::factory();

$db->exec('CREATE TABLE test (id VARCHAR(10), val VARCHAR(10), PRIMARY KEY(id))');

$data = array(
    array('10', 'Abc', 'zxy'),
    array('20', 'Def', 'wvu'),
    array('30', 'Ghi', 'tsr'),
    array('40', 'Jkl', 'qpo'),
    array('50', 'Mno', 'nml'),
    array('60', 'Pqr', 'kji'),
);

//$stmt = $db->prepare("INSERT INTO test VALUES(?, ?, ?)");
//Insertion  de trop de variable? 

// Insert using question mark placeholders
$stmt = $db->prepare("INSERT INTO test VALUES(?, ?)");
for($i =0; $i < 1000; $i++) {
    $row = array($i, "$i");
    $stmt->execute($row);

    $r = $db->query('SELECT * FROM test');
    var_dump($r->rowCount());
    unset($r);
}


$db->query('DROP TABLE test');

?>
