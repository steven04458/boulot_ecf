<?php
echo 'OK'; // no test case for this function yet
?>
