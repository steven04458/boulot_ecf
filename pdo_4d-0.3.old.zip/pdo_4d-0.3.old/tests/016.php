<?php
if (getenv('REDIR_TEST_DIR') === false) putenv('REDIR_TEST_DIR='.dirname(__FILE__) . '/../../pdo/tests/'); 
require_once getenv('REDIR_TEST_DIR') . 'pdo_test.inc';
if (!class_exists('RecursiveTreeIterator', false)) require_once(getenv('REDIR_TEST_DIR').'ext/spl/examples/recursivetreeiterator.inc'); 

$db = PDOTest::factory();

$db->exec('CREATE TABLE test(id FLOAT)');

$n = "1.";
for($i = 2; $i < 10; $i++) {
	$n .= $i;
	var_dump($db->exec('INSERT INTO test values ('.$n.')'));
}

print "\n-- recuperation --\n";

$r = $db->prepare("SELECT ROUND(id, 10) as id0, trunc(id, 10) as id1 FROM test");
$r->execute();

$x1 = $r->fetchall();

print_r($x1);

$db->exec('DROP TABLE test');

?>
