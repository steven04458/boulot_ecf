<?php
require dirname(__FILE__) . '/../../../ext/pdo/tests/pdo_test.inc';

$db = PDOTest::test_factory(dirname(__FILE__) . '/common.phpt');


$db->exec('CREATE TABLE test(id int NOT NULL, val VARCHAR(10), PRIMARY KEY (id))');
$db->exec("INSERT INTO test VALUES(1, 'A')");
$db->exec("INSERT INTO test VALUES(2, 'B')");
$db->exec("INSERT INTO test VALUES(3, 'C')");

$stmt = $db->prepare('SELECT * from test');
$stmt->execute();

var_dump($stmt->fetchAll(PDO::FETCH_ASSOC));
?>
