<?php
/*
$lang = array(
	'Japanese',
	'Arabic',
	'Arabic',
	'English',
	'German',
	'Hebraic',
	'Chinese',
	'?',
	'?',
	'?',
	'?',
	'?',
	'?',
	'?',
	'?',
	'?',
	'?',
	'?',
	'?',
	'Italian',
	'Spanish'
);
*/
require dirname(__FILE__) . '/../../../ext/pdo/tests/pdo_test.inc';
$db = PDOTest::test_factory(dirname(__FILE__) . '/common.phpt');

$db->query('CREATE TABLE T_RemoteUnicode(F_Id INT32, F_Text VARCHAR);');

// Insertion of the Unicode strings
$r = $db->prepare("INSERT INTO T_RemoteUnicode(F_Id,F_Text) VALUES (:vaL_Input, :vaT_Input);");
//$r = $db->prepare("INSERT INTO T_RemoteUnicode(F_Id,F_Text) VALUES (?, ?);");

$i = 0;
$text = '';
$r->bindParam(':vaL_Input', $i, PDO::PARAM_INT);
$r->bindParam(':vaT_Input', $text, PDO::PARAM_STR);
//$r->bindValue(1, $i, PDO::PARAM_INT);
//$r->bindValue(2, $text, PDO::PARAM_STR);

$data = file(dirname(__FILE__) . '/test.data');
$max = count($data);
for ($i = 0;$i < $max; $i++) {
	$text = $data[$i];
	$r->execute();
}

// Read the inserted Unicode strings
$r = $db->prepare('SELECT F_Id,F_Text FROM T_RemoteUnicode ORDER BY F_Id ASC;');
$r->execute();
$r->bindColumn(1, $id);
$r->bindColumn(2, $text);

$x = array();
while ($r->fetch(PDO::FETCH_BOUND)) {
	$x[$id]['id'] = $id;
	$x[$id]['ok'] = (($data[$id] === $text) ? 'Passed' : 'Failed');
//	$x[$id]['ok'] .= ' (' . $lang[$i] . ')';
}

// Cleanup of the test case
$db->query('DROP TABLE T_RemoteUnicode;');

print_r($x);
?>
