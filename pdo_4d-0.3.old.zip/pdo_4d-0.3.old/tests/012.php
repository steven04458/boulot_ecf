<?php
require dirname(__FILE__) . '/../../../ext/pdo/tests/pdo_test.inc';
$db = PDOTest::test_factory(dirname(__FILE__) . '/common.phpt');

	$r = @$db->query('CREATE TABLE test (id INT, x FLOAT)');
	if ($r == true) {
		// tests insertions
		$r = $db->query('INSERT INTO test VALUES (0, 1)');

		if ($r == true) {
			var_dump(true);
			$r = @$db->query('SELECT * FROM test');
			$l = $r->fetchall();
			
			print_r($l);
			
		} else {
			print "  INSERTION $insertion : KO\n";
		}
	$db->query('DROP TABLE IF EXISTS test ');
}

?>
