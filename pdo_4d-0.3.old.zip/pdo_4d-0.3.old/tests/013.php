<?php
if (getenv('REDIR_TEST_DIR') === false) putenv('REDIR_TEST_DIR='.dirname(__FILE__) . '/../../pdo/tests/'); 
require_once getenv('REDIR_TEST_DIR') . 'pdo_test.inc';
if (!class_exists('RecursiveTreeIterator', false)) require_once(getenv('REDIR_TEST_DIR').'ext/spl/examples/recursivetreeiterator.inc'); 

$db = PDOTest::factory();

$db->exec('CREATE TABLE test(id INT NOT NULL, primary key(id))');

$db->exec('INSERT INTO test values (1)');

$db->exec('DROP TABLE test');

$db->exec('CREATE TABLE test(id INT NOT NULL primary key)');

$db->exec('INSERT INTO test values (1)');

$db->exec('DROP TABLE IF EXISTS test');

?>
